# PrimeCloud-Minecraft-Checker

# About:
PrimeCloud Minecraft Checker is a minecraft account checker that checks Multiple Services. it supports http(s), socks4, socks5 proxies but they must be Good because microsofts authentication is very protective. it also uses tor proxies. it auto installs tor for you if selected.

Proxy Format: user:pass@ip:port and ip:port
Captures:
Xbox GP and Xbox Ultimate
Minecraft and Optifine Cape
Minecraft email access Accounts
Hypixel rank, level, first/last login, bedwars stars, skyblock coins, ban status

# Installing 
Prime Cloud Minecraft Checker only Supports WINDOWS IT WILL NOT WORK ON LINUX OR MACOS
Refrain from Selling our Services or Permant Blacklist

Make Sure you install python and git

``git clone https://github.com/Roar1608/PrimeCloud-Minecraft-Checker
cd PrimeCloud
pip install -r requirements.txt
python PrimeCloud.py``
